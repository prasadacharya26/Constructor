class Hospital{
	byte id;
	String name;
	String email;
	long contact;
	String address;
	String website;
	String type;
	
	boolean addmission(boolean bool){
		System.out.println("");
		System.out.println("addmission");
		return a;
	}
	String food(String type){
		System.out.println("");
		System.out.println("Food");
		return type;
	}
	boolean vaccancy(boolean bool){
		System.out.println("");
		System.out.println("vaccancy");
		return a;
	}
}